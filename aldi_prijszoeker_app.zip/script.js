
let products = [];

fetch('aldi.json')
  .then(res => res.json())
  .then(data => products = data);

document.getElementById('search').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  const results = products.filter(p => p.naam.toLowerCase().includes(q));
  const ul = document.getElementById('results');
  ul.innerHTML = '';
  results.forEach(p => {
    const li = document.createElement('li');
    li.textContent = `${p.naam} – €${p.prijs} (${p.inhoud})`;
    ul.appendChild(li);
  });
});
